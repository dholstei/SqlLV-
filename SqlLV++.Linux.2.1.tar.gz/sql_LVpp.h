using namespace std;

class LvDbLib {       // LabVIEW MySQL Database class
public:
    uint canary_begin; //  check for buffer overrun and that we didn't delete object
    int errnum;       // error number
    string errstr;    // error description
    string errdata;   // data precipitating error
    string SQLstate;  // SQL state
    uint16_t type;    // RDMS type, see enum db_type
    int StrBufLen;    // initialize to 256, set to zero (0) for blobs and indeterminate length string results

    union API {int dummy;} api;

#include "db_type.h"
#include "LvTypeDescriptors.h"

    LvDbLib(string ConnectionString, string user, string pw, string db, u_int16_t t);
    ~LvDbLib();
    int SetSchema(string schema);
    int Query(string query, int cols);
    int Execute(string query);
    int UpdatePrepared(string query, string v[], int rows, int cols, uint16_t ColsTD[]);
    bool GetResults(int *rows, int cols, void* types, void* results);
    uint canary_end;  //  check for buffer overrun and that we didn't delete object
};
